# PubPartner Canonical RC7

PubPartner is the persistent friend-and-governance layer between a user and interchangeable language-model providers. This reconciled private prelaunch candidate boots the friend layer, Alex/Jeremy collaboration, Pub Manager and Governance through one authenticated local launcher.

Start with [`README_START_HERE.md`](README_START_HERE.md). Do not treat this package as publicly market-ready; current limitations and raw verification evidence are included.

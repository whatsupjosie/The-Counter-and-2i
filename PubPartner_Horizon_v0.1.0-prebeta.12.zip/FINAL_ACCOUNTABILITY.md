# Final Accountability

## 1. Where did this pass cut corners?

It did not execute native Windows, live Ollama, live OpenAI-compatible providers, or real camera/recording/renderer hardware. It also did not fully port every independently useful Alex Prime capability into the active friend path because doing so would create or risk duplicate authority, identity and memory systems without a dedicated contract migration.

## 2. What was left out?

Public installer/signing, production deployment, external-provider live certification, hardware studio certification, accessibility review, performance/load testing, and a complete redesign of older studio TODO integrations.

## 3. Which claims were directly verified?

Archive hashes/extraction, current test counts, current preflight, mock friend loop, receipts, authenticated restart, route registration, authority ban/freeze/replay behavior, selected donor test results, cross-build hashes, and release sanitation.

## 4. Which claims rely on prior handoffs?

Historical intent and some subsystem descriptions originate in supplied handoff documents. They were not treated as proof when current code/tests could be checked. Hardware behavior and old production achievements not reproducible here remain historical claims.

## 5. Which tests were skipped or blocked?

Three live-Ollama tests were skipped. Native Windows and live external-provider/hardware scenarios were blocked by environment.

## 6. Which capabilities are present but not wired by default?

Bubble Stack, Room Conductor full production mode, e-PETE, camera, recording, voxel/Rust renderer, choreography, avatar and Studio systems. They are retained in `main.py` but intentionally not started by the lightweight launcher.

## 7. Which capabilities are wired but degraded?

Optional Jeremy Cricket can fall back if unavailable. e-PETE/renderer and full studio bridges can report fallback/degraded states in the full host. External providers are unavailable without their services/keys.

## 8. What could have been misinterpreted?

Older files use names as roles, characters and implementation labels interchangeably. This pass resolved by function/contract and may still have classified a useful historical donor as reference rather than future canonical support. The source audit makes those decisions reversible.

## 9. Was protected authored content edited?

No. No authored material under `source_locked/` was edited, rewritten or normalized.

## 10. Can another engineer continue without the original chat?

Yes for the canonical runtime and the decisions made in this pass: the package contains startup truth, contract map, provenance, conflict ledger, raw evidence, limitations, source inventories and hashes. The original source archives remain useful for deeper historical archaeology but are not required to boot or understand this canonical candidate.

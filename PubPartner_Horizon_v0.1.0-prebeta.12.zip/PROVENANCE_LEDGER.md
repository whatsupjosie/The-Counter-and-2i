# Provenance Ledger

## Canonical Line

1. `PubPartner_PRELAUNCH_RC2_PUB_MANAGER_20260711.zip` — Pub Manager authority/control plane base.
2. `PubPartner_RC2_HANDOFF_20260712.zip` — authentication, first-run and restart-continuity productization.
3. `PubPartner_PRELAUNCH_RC6_PROVIDER_NEUTRALIZER_20260712.zip` — selected base; provider neutralization and broader provider boundary.
4. Canonical Reconciliation RC7 — repaired default control-plane wiring, release sanitation, adversarial authority coverage, provenance and packaging.

## Verified Supporting Line

`PubCast_v5_6_verified_and_fixed_2026-07-12.zip` and `PubCast_v5_6_BubbleStack_WIRED_2026-07-06.zip` were used to verify that important studio modules in RC6 correspond to the repaired/finalized PubCast implementations rather than unrelated namesakes.

## Donor/Reference Line

- `alex_prime_core_v0_10(1).zip`: validated independently, 55 tests passed.
- `alex_core_adaptive_companion.zip`: validated independently, 4 tests passed.
- `Pubcast_AI_Locall.zip`: validated independently, 215 tests passed.
- `JEREMY_CRICKET_HARDENED_BETA`: 21 passed, 1 failed under compatible asyncio mode; not accepted into runtime.
- loose `governance (1)(2).py` and `test_pub_manager.py`: historical/alternate contract references.

Full source package hashes, extraction maps, duplicate groups, symbol inventory, route tables and cross-build comparisons are under `docs/reconciliation/source_audit/`.

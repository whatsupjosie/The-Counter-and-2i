# Final Release File Canonicality Table

This table classifies the sanitized canonical release, not the preserved donor archive.

## Counts

- `CANONICAL_ACTIVE`: 39
- `CANONICAL_DOCUMENTATION`: 71
- `CANONICAL_RUNTIME_BINARY`: 7
- `CANONICAL_SUPPORT`: 60
- `CANONICAL_SUPPORT_NOT_BOOTED`: 99
- `CANONICAL_TEST`: 34
- `CANONICAL_UI_ASSET`: 14

## Files

| File | Status | Size | SHA-256 | Runtime note |
|---|---|---:|---|---|
| `.env.example` | `CANONICAL_SUPPORT` | 1052 | `ad0615ab5b0c5272…` |  |
| `.gitignore` | `CANONICAL_SUPPORT` | 1569 | `06650df136827a81…` |  |
| `ALEX_PROFILE_SCHEMA/alex_profile.schema.json` | `CANONICAL_SUPPORT` | 1876 | `98349656281e9f23…` |  |
| `AUTHORITY_ADVERSARIAL_REPORT.md` | `CANONICAL_DOCUMENTATION` | 1665 | `ec75e4a59c55f080…` |  |
| `BOOT_SEQUENCE.md` | `CANONICAL_DOCUMENTATION` | 968 | `2151b9bf40f0081e…` |  |
| `CAPABILITY_CONTRACT_MAP.md` | `CANONICAL_DOCUMENTATION` | 4328 | `e090535629f1e7cd…` |  |
| `CONFLICT_RESOLUTION_LEDGER.md` | `CANONICAL_DOCUMENTATION` | 2982 | `088c990cb4b3e52c…` |  |
| `COPYRIGHT.md` | `CANONICAL_DOCUMENTATION` | 1173 | `fe83ab3a2b5215b6…` |  |
| `CURRENT_RUNTIME_TRUTH.md` | `CANONICAL_DOCUMENTATION` | 3532 | `199662e0ce86375e…` |  |
| `FILE_CHANGE_SUMMARY.md` | `CANONICAL_DOCUMENTATION` | 1388 | `06c8416e01a31c47…` |  |
| `FINAL_ACCOUNTABILITY.md` | `CANONICAL_DOCUMENTATION` | 2882 | `c28cceaf301a6c9b…` |  |
| `KNOWN_LIMITATIONS.md` | `CANONICAL_DOCUMENTATION` | 1172 | `29bb9cdf4e43d50a…` |  |
| `POWERSHELL_QUICK_START.txt` | `CANONICAL_DOCUMENTATION` | 692 | `1cf863e347eae4c8…` |  |
| `PROCESS_AND_DISK_ACCOUNTING.md` | `CANONICAL_DOCUMENTATION` | 1285 | `4fcc04f02adc12a1…` |  |
| `PROVENANCE_LEDGER.md` | `CANONICAL_DOCUMENTATION` | 1457 | `3ed048ac5a32e638…` |  |
| `QUICK_START.md` | `CANONICAL_DOCUMENTATION` | 3237 | `c6e8350457f4be1d…` |  |
| `README.md` | `CANONICAL_DOCUMENTATION` | 486 | `f938fea7e6cc11e3…` |  |
| `README_START_HERE.md` | `CANONICAL_DOCUMENTATION` | 3410 | `64945d260a00f3cb…` |  |
| `RUNTIME_IMPORT_GRAPH.md` | `CANONICAL_DOCUMENTATION` | 1184 | `d95b6ccce3defb0d…` |  |
| `RUN_PUBPARTNER_WINDOWS.bat` | `CANONICAL_ACTIVE` | 1779 | `6331ea03a7a17649…` | default runtime |
| `SIMPLE_WINDOWS_RUN_INSTRUCTIONS.md` | `CANONICAL_DOCUMENTATION` | 808 | `7fbdb524fd557891…` |  |
| `STARTUP.md` | `CANONICAL_DOCUMENTATION` | 883 | `c735dff33625552e…` |  |
| `TEST_RESULTS_SUMMARY.md` | `CANONICAL_DOCUMENTATION` | 1176 | `8fe060a854595adc…` |  |
| `UNREACHABLE_OR_UNWIRED_COMPONENTS.md` | `CANONICAL_DOCUMENTATION` | 1726 | `dcfad1edb0ac9094…` |  |
| `VERSION` | `CANONICAL_SUPPORT` | 46 | `c6bf689fb0804e45…` |  |
| `WINDOWS_LAUNCH_VERIFICATION.md` | `CANONICAL_DOCUMENTATION` | 1317 | `ad08904f0f4b5944…` |  |
| `assets/.gitkeep` | `CANONICAL_UI_ASSET` | 0 | `e3b0c44298fc1c14…` |  |
| `assets/avatars/manny.glb` | `CANONICAL_UI_ASSET` | 120940 | `af31bc6394ed6025…` |  |
| `assets/avatars/sheila.glb` | `CANONICAL_UI_ASSET` | 120956 | `86f48074bef287a3…` |  |
| `bin/ws_renderer` | `CANONICAL_RUNTIME_BINARY` | 9687192 | `073be6aeebd72066…` |  |
| `conftest.py` | `CANONICAL_TEST` | 1485 | `d578a5a7eb048f71…` |  |
| `data/.gitkeep` | `CANONICAL_SUPPORT` | 0 | `e3b0c44298fc1c14…` |  |
| `data/alex_bridge/.gitkeep` | `CANONICAL_SUPPORT` | 0 | `e3b0c44298fc1c14…` |  |
| `data/black_box/.gitkeep` | `CANONICAL_SUPPORT` | 0 | `e3b0c44298fc1c14…` |  |
| `data/byok/secure/.gitkeep` | `CANONICAL_SUPPORT` | 0 | `e3b0c44298fc1c14…` |  |
| `data/emergency_bridge/commands/.gitkeep` | `CANONICAL_SUPPORT` | 0 | `e3b0c44298fc1c14…` |  |
| `data/emergency_bridge/responses/.gitkeep` | `CANONICAL_SUPPORT` | 0 | `e3b0c44298fc1c14…` |  |
| `data/emergency_saves/.gitkeep` | `CANONICAL_SUPPORT` | 0 | `e3b0c44298fc1c14…` |  |
| `data/governance/.gitkeep` | `CANONICAL_SUPPORT` | 0 | `e3b0c44298fc1c14…` |  |
| `data/logs/.gitkeep` | `CANONICAL_SUPPORT` | 0 | `e3b0c44298fc1c14…` |  |
| `data/pub_manager/authority/.gitkeep` | `CANONICAL_SUPPORT` | 0 | `e3b0c44298fc1c14…` |  |
| `data/pubpartner/authority/.gitkeep` | `CANONICAL_SUPPORT` | 0 | `e3b0c44298fc1c14…` |  |
| `data/pubpartner/backups/.gitkeep` | `CANONICAL_SUPPORT` | 0 | `e3b0c44298fc1c14…` |  |
| `data/pubpartner/guidance/.gitkeep` | `CANONICAL_SUPPORT` | 0 | `e3b0c44298fc1c14…` |  |
| `data/pubpartner/profiles/friends/alex.json` | `CANONICAL_SUPPORT` | 2161 | `62591e3209aef124…` |  |
| `data/pubpartner/profiles/friends/craig.json` | `CANONICAL_SUPPORT` | 629 | `7e1e4f6ec943cd9f…` |  |
| `data/pubpartner/profiles/friends/friend.json` | `CANONICAL_SUPPORT` | 542 | `8e7d1d50ff3822f8…` |  |
| `data/pubpartner/profiles/providers/anthropic.json` | `CANONICAL_SUPPORT` | 209 | `882c204161860c7a…` |  |
| `data/pubpartner/profiles/providers/gemini.json` | `CANONICAL_SUPPORT` | 198 | `740a8106d5e1d0ac…` |  |
| `data/pubpartner/profiles/providers/groq.json` | `CANONICAL_SUPPORT` | 180 | `a720680437e3915d…` |  |
| `data/pubpartner/profiles/providers/mistral.json` | `CANONICAL_SUPPORT` | 204 | `ed1c331535b34ae7…` |  |
| `data/pubpartner/profiles/providers/mock.json` | `CANONICAL_SUPPORT` | 160 | `eb834362cdd7fbc5…` |  |
| `data/pubpartner/profiles/providers/offline.json` | `CANONICAL_SUPPORT` | 195 | `904405b90b70f7da…` |  |
| `data/pubpartner/profiles/providers/ollama.json` | `CANONICAL_SUPPORT` | 232 | `fdf3df1259c2e444…` |  |
| `data/pubpartner/profiles/providers/openai.json` | `CANONICAL_SUPPORT` | 220 | `d5835e8ca7be88b3…` |  |
| `data/pubpartner/profiles/providers/openai_compatible.json` | `CANONICAL_SUPPORT` | 193 | `a4ef30a7145f4625…` |  |
| `data/pubpartner/profiles/providers/opencode_zen.json` | `CANONICAL_SUPPORT` | 221 | `c8557068b432ba54…` |  |
| `data/pubpartner/profiles/users/.gitkeep` | `CANONICAL_SUPPORT` | 0 | `e3b0c44298fc1c14…` |  |
| `data/pubpartner/receipts/.gitkeep` | `CANONICAL_SUPPORT` | 0 | `e3b0c44298fc1c14…` |  |
| `data/pubpartner/relationship/.gitkeep` | `CANONICAL_SUPPORT` | 0 | `e3b0c44298fc1c14…` |  |
| `data/pubpartner/secure/.gitkeep` | `CANONICAL_SUPPORT` | 0 | `e3b0c44298fc1c14…` |  |
| `data/pubpartner/sessions/.gitkeep` | `CANONICAL_SUPPORT` | 0 | `e3b0c44298fc1c14…` |  |
| `data/pubpartner/verbatim/.gitkeep` | `CANONICAL_SUPPORT` | 0 | `e3b0c44298fc1c14…` |  |
| `data/system/.gitkeep` | `CANONICAL_SUPPORT` | 0 | `e3b0c44298fc1c14…` |  |
| `data/vault/.gitkeep` | `CANONICAL_SUPPORT` | 0 | `e3b0c44298fc1c14…` |  |
| `data/voxel_asset_library.json` | `CANONICAL_SUPPORT` | 344 | `97de02ba5243b0f5…` |  |
| `docs/reconciliation/AGENT_JOB_SPEC.md` | `CANONICAL_DOCUMENTATION` | 17787 | `62c73899e4a0a349…` |  |
| `docs/reconciliation/raw_test_output/ALEX_ADAPTIVE_PYTEST.txt` | `CANONICAL_DOCUMENTATION` | 105 | `3ab383e3bb40096d…` |  |
| `docs/reconciliation/raw_test_output/ALEX_PRIME_FULL_PYTEST.txt` | `CANONICAL_DOCUMENTATION` | 124 | `3dd899076277590b…` |  |
| `docs/reconciliation/raw_test_output/JEREMY_HARDENED_PYTEST.txt` | `CANONICAL_DOCUMENTATION` | 31245 | `bc8c26d18a8346f9…` |  |
| `docs/reconciliation/raw_test_output/JEREMY_HARDENED_PYTEST_ASYNCIO_AUTO.txt` | `CANONICAL_DOCUMENTATION` | 1528 | `cf4601d5ecb1d104…` |  |
| `docs/reconciliation/raw_test_output/PUBCAST_LOCAL_PYTEST.txt` | `CANONICAL_DOCUMENTATION` | 23009 | `b6269a3885f397e2…` |  |
| `docs/reconciliation/raw_test_output/RC2_HANDOFF_FULL_PYTEST.txt` | `CANONICAL_DOCUMENTATION` | 205 | `b121813dfbb20a70…` |  |
| `docs/reconciliation/raw_test_output/RC6_AUTHORITY_FOCUSED_PYTEST.txt` | `CANONICAL_DOCUMENTATION` | 3384 | `e41b9333d5b733c1…` |  |
| `docs/reconciliation/raw_test_output/RC6_FULL_PYTEST.txt` | `CANONICAL_DOCUMENTATION` | 206 | `4c27d9e89818eb98…` |  |
| `docs/reconciliation/raw_test_output/RC6_LOCAL_SMOKE.txt` | `CANONICAL_DOCUMENTATION` | 1029 | `387a6a7ea5eb6064…` |  |
| `docs/reconciliation/raw_test_output/RC6_MANIFEST_VERIFY.json` | `CANONICAL_DOCUMENTATION` | 108 | `fa090215edf99085…` |  |
| `docs/reconciliation/raw_test_output/RC6_PREFLIGHT.txt` | `CANONICAL_DOCUMENTATION` | 3791 | `a184c0fa34405ba1…` |  |
| `docs/reconciliation/raw_test_output/RC6_RESTART_PROBE.txt` | `CANONICAL_DOCUMENTATION` | 285 | `e44c7f3a08cdcde4…` |  |
| `docs/reconciliation/raw_test_output/RC7_COMPILEALL.txt` | `CANONICAL_DOCUMENTATION` | 15 | `9c638c086e70d900…` |  |
| `docs/reconciliation/raw_test_output/RC7_FINAL_CONTROL_PLANE_PROBE.txt` | `CANONICAL_DOCUMENTATION` | 528 | `58b871aa868d204e…` |  |
| `docs/reconciliation/raw_test_output/RC7_FINAL_LOCAL_SMOKE.txt` | `CANONICAL_DOCUMENTATION` | 1016 | `1d1d20a1a1de0dfd…` |  |
| `docs/reconciliation/raw_test_output/RC7_FINAL_PREFLIGHT.txt` | `CANONICAL_DOCUMENTATION` | 4008 | `625d533447c85561…` |  |
| `docs/reconciliation/raw_test_output/RC7_FINAL_RELEASE_SANITIZE.txt` | `CANONICAL_DOCUMENTATION` | 2003 | `2657e8d6fa088c17…` |  |
| `docs/reconciliation/raw_test_output/RC7_FINAL_RESTART_PROBE.txt` | `CANONICAL_DOCUMENTATION` | 264 | `dd59b4a8d7f35469…` |  |
| `docs/reconciliation/raw_test_output/RC7_FULL_PYTEST.txt` | `CANONICAL_DOCUMENTATION` | 206 | `20b4f6bb465aaae6…` |  |
| `docs/reconciliation/raw_test_output/RC7_INITIAL_SANITIZE.txt` | `CANONICAL_DOCUMENTATION` | 303 | `d29821a19f11be1f…` |  |
| `docs/reconciliation/raw_test_output/RC7_JS_SYNTAX.txt` | `CANONICAL_DOCUMENTATION` | 0 | `e3b0c44298fc1c14…` |  |
| `docs/reconciliation/raw_test_output/RC7_LOCAL_SMOKE.txt` | `CANONICAL_DOCUMENTATION` | 1016 | `74f96e4da5739d67…` |  |
| `docs/reconciliation/raw_test_output/RC7_PACKAGED_CONTROL_PLANE_PROBE.txt` | `CANONICAL_DOCUMENTATION` | 528 | `58b871aa868d204e…` |  |
| `docs/reconciliation/raw_test_output/RC7_PACKAGED_FULL_VALIDATION.txt` | `CANONICAL_DOCUMENTATION` | 216 | `c343367997efe830…` |  |
| `docs/reconciliation/raw_test_output/RC7_PACKAGED_LOCAL_SMOKE.txt` | `CANONICAL_DOCUMENTATION` | 1016 | `de373259239d323f…` |  |
| `docs/reconciliation/raw_test_output/RC7_PACKAGED_PREFLIGHT.txt` | `CANONICAL_DOCUMENTATION` | 4010 | `e387929a2b39d322…` |  |
| `docs/reconciliation/raw_test_output/RC7_PACKAGED_RESTART_PROBE.txt` | `CANONICAL_DOCUMENTATION` | 264 | `156c00f655657a4e…` |  |
| `docs/reconciliation/raw_test_output/RC7_PATH_WITH_SPACES_PREFLIGHT.txt` | `CANONICAL_DOCUMENTATION` | 4153 | `a94b739984b623ef…` |  |
| `docs/reconciliation/raw_test_output/RC7_POST_CONTROL_PLANE_COMPILE.txt` | `CANONICAL_DOCUMENTATION` | 0 | `e3b0c44298fc1c14…` |  |
| `docs/reconciliation/raw_test_output/RC7_POST_CONTROL_PLANE_FULL_PYTEST.txt` | `CANONICAL_DOCUMENTATION` | 216 | `424d5fc30803d640…` |  |
| `docs/reconciliation/raw_test_output/RC7_POST_CONTROL_PLANE_JS.txt` | `CANONICAL_DOCUMENTATION` | 0 | `e3b0c44298fc1c14…` |  |
| `docs/reconciliation/raw_test_output/RC7_POST_VALIDATION_SANITIZE.txt` | `CANONICAL_DOCUMENTATION` | 1432 | `c84f8e735e763f54…` |  |
| `docs/reconciliation/raw_test_output/RC7_PREFLIGHT.txt` | `CANONICAL_DOCUMENTATION` | 4254 | `c806c9ce454a4fff…` |  |
| `docs/reconciliation/raw_test_output/RC7_RESTART_PROBE.txt` | `CANONICAL_DOCUMENTATION` | 271 | `bc8c704a511adae9…` |  |
| `docs/reconciliation/raw_test_output/RC7_WINDOWS_LAUNCHER_STATIC.txt` | `CANONICAL_DOCUMENTATION` | 3556 | `7845c170b7ffac08…` |  |
| `docs/reconciliation/source_audit/ARCHIVE_OVERVIEW.csv` | `CANONICAL_DOCUMENTATION` | 4855 | `3ec308af3972b824…` |  |
| `docs/reconciliation/source_audit/EXTRACTION_MAP.csv` | `CANONICAL_DOCUMENTATION` | 2966 | `170710710c3fdea6…` |  |
| `docs/reconciliation/source_audit/EXTRACTION_MAP.md` | `CANONICAL_DOCUMENTATION` | 2476 | `616c79cde752c230…` |  |
| `docs/reconciliation/source_audit/NESTED_ARCHIVE_INVENTORY.csv` | `CANONICAL_DOCUMENTATION` | 1780 | `d1f2d7dfd47bd80b…` |  |
| `docs/reconciliation/source_audit/PYTHON_TOPLEVEL_SYMBOL_INVENTORY.csv` | `CANONICAL_DOCUMENTATION` | 150819 | `db76d2349487093b…` |  |
| `docs/reconciliation/source_audit/RC6_PUBCAST_KEY_MODULE_RECONCILIATION.csv` | `CANONICAL_DOCUMENTATION` | 4603 | `771a4fea080a9396…` |  |
| `docs/reconciliation/source_audit/RECURSIVE_NESTED_EXTRACTION.csv` | `CANONICAL_DOCUMENTATION` | 4406 | `0de396bb328e7fcf…` |  |
| `docs/reconciliation/source_audit/ROUTE_REGISTRATION_TABLE.csv` | `CANONICAL_DOCUMENTATION` | 13007 | `0c1fd7797e13fd3d…` |  |
| `docs/reconciliation/source_audit/ROUTE_REGISTRATION_TABLE_FINAL.csv` | `CANONICAL_DOCUMENTATION` | 8137 | `83fd5cd3d466daee…` |  |
| `docs/reconciliation/source_audit/SOURCE_PACKAGE_HASHES.sha256` | `CANONICAL_DOCUMENTATION` | 3756 | `50297b14162cfa33…` |  |
| `docs/reconciliation/source_audit/SOURCE_PACKAGE_INVENTORY.csv` | `CANONICAL_DOCUMENTATION` | 4182 | `8e3edc9dfa718571…` |  |
| `docs/reconciliation/source_audit/STATIC_STRUCTURAL_SCAN.json` | `CANONICAL_DOCUMENTATION` | 16830 | `b87f985eff7d3721…` |  |
| `docs/reconciliation/source_audit/THREE_WAY_FILE_COMPARISON.csv` | `CANONICAL_DOCUMENTATION` | 105805 | `bf68d9a66e7100a1…` |  |
| `main.py` | `CANONICAL_SUPPORT_NOT_BOOTED` | 121397 | `e5e8672b528dc83c…` | optional/full-host support |
| `modules/__init__.py` | `CANONICAL_SUPPORT_NOT_BOOTED` | 216 | `b20476a224dd1c05…` | optional/full-host support |
| `modules/alex_core.py` | `CANONICAL_ACTIVE` | 39226 | `dd84aadc9d83cb15…` | default runtime |
| `modules/alex_jeremy_bridge.py` | `CANONICAL_ACTIVE` | 26361 | `9a977d21182a71d7…` | default runtime |
| `modules/alex_routes.py` | `CANONICAL_ACTIVE` | 4904 | `4bd140b1c1b89cb9…` | default runtime |
| `modules/appconfig.py` | `CANONICAL_ACTIVE` | 2902 | `c801d55b34ec7d2e…` | default runtime |
| `modules/auth.py` | `CANONICAL_ACTIVE` | 9135 | `7d4ff346d84e2b07…` | default runtime |
| `modules/auth_rate_limit.py` | `CANONICAL_SUPPORT_NOT_BOOTED` | 2695 | `91d9acdcb226f14e…` | optional/full-host support |
| `modules/auth_routes.py` | `CANONICAL_ACTIVE` | 6734 | `d8d8256e0e99c796…` | default runtime |
| `modules/avatar.py` | `CANONICAL_SUPPORT_NOT_BOOTED` | 9752 | `8963d8cb61c346a9…` | optional/full-host support |
| `modules/avatar_assets.py` | `CANONICAL_SUPPORT_NOT_BOOTED` | 2697 | `d1f4ceec27a6d72c…` | optional/full-host support |
| `modules/avatar_motion.py` | `CANONICAL_SUPPORT_NOT_BOOTED` | 572 | `fa6b02daa5986215…` | optional/full-host support |
| `modules/avatar_performer.py` | `CANONICAL_SUPPORT_NOT_BOOTED` | 41834 | `e47e33542f3de6fe…` | optional/full-host support |
| `modules/avatar_skeleton_system.py` | `CANONICAL_SUPPORT_NOT_BOOTED` | 13441 | `2cb60b981258d1e4…` | optional/full-host support |
| `modules/avatar_studio_bridge.py` | `CANONICAL_SUPPORT_NOT_BOOTED` | 7666 | `3b2b241dbbb71aa4…` | optional/full-host support |
| `modules/avatar_system_raw.py` | `CANONICAL_SUPPORT_NOT_BOOTED` | 29987 | `3388451dcb517507…` | optional/full-host support |
| `modules/bot_llm_adapter.py` | `CANONICAL_SUPPORT_NOT_BOOTED` | 16330 | `22a554200113300f…` | optional/full-host support |
| `modules/bots.py` | `CANONICAL_SUPPORT_NOT_BOOTED` | 20352 | `c3e489317070970c…` | optional/full-host support |
| `modules/bridge.py` | `CANONICAL_SUPPORT_NOT_BOOTED` | 3047 | `b351963fd3ea88c0…` | optional/full-host support |
| `modules/bridge_bulletproof.py` | `CANONICAL_SUPPORT_NOT_BOOTED` | 45677 | `cba8f9a4d1698e05…` | optional/full-host support |
| `modules/bridge_raw.py` | `CANONICAL_SUPPORT_NOT_BOOTED` | 13615 | `47457b6b5c92ef6e…` | optional/full-host support |
| `modules/bubble_jeremy_adapter.py` | `CANONICAL_SUPPORT_NOT_BOOTED` | 2938 | `6fb745f039cd447f…` | optional/full-host support |
| `modules/bubble_routes.py` | `CANONICAL_SUPPORT_NOT_BOOTED` | 6015 | `1087592b8993001d…` | optional/full-host support |
| `modules/bubble_stack.py` | `CANONICAL_SUPPORT_NOT_BOOTED` | 20015 | `b32941649d8cebb3…` | optional/full-host support |
| `modules/bubble_stack_pikpc/__init__.py` | `CANONICAL_SUPPORT_NOT_BOOTED` | 888 | `0ea6944947f23987…` | optional/full-host support |
| `modules/bubble_stack_pikpc/core.py` | `CANONICAL_SUPPORT_NOT_BOOTED` | 10995 | `0b5f1be7bc15e17e…` | optional/full-host support |
| `modules/bubble_stack_pikpc/engine.py` | `CANONICAL_SUPPORT_NOT_BOOTED` | 27360 | `c097a244d9e119b6…` | optional/full-host support |
| `modules/bubble_stack_pikpc/performance.py` | `CANONICAL_SUPPORT_NOT_BOOTED` | 9929 | `ed092695ce120f30…` | optional/full-host support |
| `modules/bubble_stack_pikpc/routes.py` | `CANONICAL_SUPPORT_NOT_BOOTED` | 1683 | `86a304217e91d3ee…` | optional/full-host support |
| `modules/bubble_stack_pikpc/sandbox.py` | `CANONICAL_SUPPORT_NOT_BOOTED` | 34164 | `43c5c48ce7d3e94d…` | optional/full-host support |
| `modules/byok_manager.py` | `CANONICAL_ACTIVE` | 23043 | `cfbb0f068e2b712f…` | default runtime |
| `modules/byok_routes.py` | `CANONICAL_ACTIVE` | 15022 | `9327fddd4475a7bf…` | default runtime |
| `modules/camera_manager.py` | `CANONICAL_SUPPORT_NOT_BOOTED` | 1068 | `f7e0cde08305063e…` | optional/full-host support |
| `modules/cameras.py` | `CANONICAL_SUPPORT_NOT_BOOTED` | 8184 | `a90e85e55532eb25…` | optional/full-host support |
| `modules/cameras_advanced.py` | `CANONICAL_SUPPORT_NOT_BOOTED` | 42171 | `af23b4369c810808…` | optional/full-host support |
| `modules/character_cast.py` | `CANONICAL_SUPPORT_NOT_BOOTED` | 6421 | `379ad4833dd26eaa…` | optional/full-host support |
| `modules/character_engine.py` | `CANONICAL_SUPPORT_NOT_BOOTED` | 24631 | `c801ef08601a4d5c…` | optional/full-host support |
| `modules/character_profiles.py` | `CANONICAL_SUPPORT_NOT_BOOTED` | 14956 | `508b122c0bba5a66…` | optional/full-host support |
| `modules/character_routes.py` | `CANONICAL_SUPPORT_NOT_BOOTED` | 3159 | `c3584ede41fbd8f1…` | optional/full-host support |
| `modules/choreography_controller.py` | `CANONICAL_SUPPORT_NOT_BOOTED` | 14844 | `9dcd1f0d137a36d8…` | optional/full-host support |
| `modules/choreography_runtime.py` | `CANONICAL_SUPPORT_NOT_BOOTED` | 5881 | `0d5147cd6d5c07ff…` | optional/full-host support |
| `modules/circuit_breaker.py` | `CANONICAL_SUPPORT_NOT_BOOTED` | 9202 | `7be40c84283699b0…` | optional/full-host support |
| `modules/credentials.py` | `CANONICAL_SUPPORT_NOT_BOOTED` | 13255 | `f68f28cebffccae7…` | optional/full-host support |
| `modules/credits_export.py` | `CANONICAL_SUPPORT_NOT_BOOTED` | 3478 | `09304818a7603351…` | optional/full-host support |
| `modules/doctor.py` | `CANONICAL_SUPPORT_NOT_BOOTED` | 21072 | `670ea072a247c622…` | optional/full-host support |
| `modules/dressing_room_security.py` | `CANONICAL_ACTIVE` | 16796 | `93368ddbb0f8ebe6…` | default runtime |
| `modules/ethereal_avatars.py` | `CANONICAL_SUPPORT_NOT_BOOTED` | 18777 | `743f6f351e9d9fe7…` | optional/full-host support |
| `modules/governance.py` | `CANONICAL_ACTIVE` | 22987 | `db5584a2482113c7…` | default runtime |
| `modules/governance_routes.py` | `CANONICAL_ACTIVE` | 21389 | `1cac3fb73561d240…` | default runtime |
| `modules/governance_waiting_room.py` | `CANONICAL_SUPPORT_NOT_BOOTED` | 29192 | `1f91bfba582e183b…` | optional/full-host support |
| `modules/hotspot_system.py` | `CANONICAL_SUPPORT_NOT_BOOTED` | 9015 | `8e9ebfa24bd494b5…` | optional/full-host support |
| `modules/hub.py` | `CANONICAL_SUPPORT_NOT_BOOTED` | 8372 | `c50bda94c8c93e42…` | optional/full-host support |
| `modules/inference.py` | `CANONICAL_SUPPORT_NOT_BOOTED` | 9077 | `eedb7c5735f72761…` | optional/full-host support |
| `modules/irm.py` | `CANONICAL_SUPPORT_NOT_BOOTED` | 12106 | `9b652a54577b12ea…` | optional/full-host support |
| `modules/jeremy_cricket.py` | `CANONICAL_ACTIVE` | 22420 | `d58397c8f94d7530…` | default runtime |
| `modules/lighting.py` | `CANONICAL_SUPPORT_NOT_BOOTED` | 8103 | `2d12c531a78e2800…` | optional/full-host support |
| `modules/lighting_engine.py` | `CANONICAL_SUPPORT_NOT_BOOTED` | 42972 | `bf39c67843b09fcb…` | optional/full-host support |
| `modules/llm_framework.py` | `CANONICAL_SUPPORT_NOT_BOOTED` | 34775 | `feb38f946d9702b0…` | optional/full-host support |
| `modules/llm_orchestrator.py` | `CANONICAL_SUPPORT_NOT_BOOTED` | 30915 | `eee3913213980b7c…` | optional/full-host support |
| `modules/memory_engine.py` | `CANONICAL_SUPPORT_NOT_BOOTED` | 4555 | `a6e971247ef7717c…` | optional/full-host support |
| `modules/memory_routes.py` | `CANONICAL_SUPPORT_NOT_BOOTED` | 19153 | `63af9e26f3a0de4f…` | optional/full-host support |
| `modules/mocap_integration.py` | `CANONICAL_SUPPORT_NOT_BOOTED` | 23158 | `b423d66ef19421f5…` | optional/full-host support |
| `modules/mocap_precision.py` | `CANONICAL_SUPPORT_NOT_BOOTED` | 44170 | `8514db42b414c9c8…` | optional/full-host support |
| `modules/mode_resolver.py` | `CANONICAL_SUPPORT_NOT_BOOTED` | 6969 | `a41f0fda9daaa214…` | optional/full-host support |
| `modules/models.py` | `CANONICAL_ACTIVE` | 3831 | `6065a35ee954910c…` | default runtime |
| `modules/ollama_provider.py` | `CANONICAL_ACTIVE` | 9262 | `13d696c859acb348…` | default runtime |
| `modules/openai_compatible_provider.py` | `CANONICAL_ACTIVE` | 4516 | `b7bbdc6fe3893e46…` | default runtime |
| `modules/opencode_zen.py` | `CANONICAL_ACTIVE` | 11637 | `d73ae669d2df8061…` | default runtime |
| `modules/orchestrator.py` | `CANONICAL_SUPPORT_NOT_BOOTED` | 3919 | `dbe6a394c175244c…` | optional/full-host support |
| `modules/orchestrator_raw.py` | `CANONICAL_SUPPORT_NOT_BOOTED` | 10509 | `acc3f4a5440cfc6c…` | optional/full-host support |
| `modules/performance_manager.py` | `CANONICAL_SUPPORT_NOT_BOOTED` | 5885 | `f1de679d8e1caca2…` | optional/full-host support |
| `modules/persistence.py` | `CANONICAL_SUPPORT_NOT_BOOTED` | 6416 | `7f52478f4649834e…` | optional/full-host support |
| `modules/pete_enhanced.py` | `CANONICAL_SUPPORT_NOT_BOOTED` | 46562 | `c69870ca16e60ffa…` | optional/full-host support |
| `modules/pete_enhanced_routes.py` | `CANONICAL_SUPPORT_NOT_BOOTED` | 6492 | `33396de42645e6c0…` | optional/full-host support |
| `modules/posture_library.py` | `CANONICAL_SUPPORT_NOT_BOOTED` | 2129 | `80e32fc6598be4de…` | optional/full-host support |
| `modules/production_routes.py` | `CANONICAL_SUPPORT_NOT_BOOTED` | 19823 | `9c3fab8204fd63c1…` | optional/full-host support |
| `modules/projects.py` | `CANONICAL_SUPPORT_NOT_BOOTED` | 2650 | `39a6c041ec7ff045…` | optional/full-host support |
| `modules/provider_capabilities.py` | `CANONICAL_ACTIVE` | 3551 | `03eda65e1c066d23…` | default runtime |
| `modules/provider_neutralizer.py` | `CANONICAL_ACTIVE` | 9583 | `80c6d93de72f3c58…` | default runtime |
| `modules/pub_manager_authority.py` | `CANONICAL_ACTIVE` | 31756 | `413e8f8353effa3e…` | default runtime |
| `modules/pub_manager_decision.py` | `CANONICAL_ACTIVE` | 15417 | `af063ae8dbfd9c37…` | default runtime |
| `modules/pubcast_room_layout.py` | `CANONICAL_SUPPORT_NOT_BOOTED` | 20406 | `b2b6b68568743e10…` | optional/full-host support |
| `modules/pubcast_story_bible.py` | `CANONICAL_SUPPORT_NOT_BOOTED` | 35432 | `5fdaa4d25c77daa2…` | optional/full-host support |
| `modules/pubcast_vault.py` | `CANONICAL_SUPPORT_NOT_BOOTED` | 7081 | `8d9f9ceb9121fbc2…` | optional/full-host support |
| `modules/pubcast_voxel_integration.py` | `CANONICAL_SUPPORT_NOT_BOOTED` | 2766 | `8b56fa1041230d72…` | optional/full-host support |
| `modules/pubpartner_backup.py` | `CANONICAL_ACTIVE` | 4460 | `07580f357fdd6943…` | default runtime |
| `modules/pubpartner_core.py` | `CANONICAL_ACTIVE` | 63091 | `0cf95e731ddefc33…` | default runtime |
| `modules/pubpartner_guidance.py` | `CANONICAL_ACTIVE` | 4780 | `0d8270fedfe5bb1d…` | default runtime |
| `modules/pubpartner_knowledge.py` | `CANONICAL_ACTIVE` | 14739 | `ddb34d1a00e8d9b1…` | default runtime |
| `modules/pubpartner_preflight.py` | `CANONICAL_SUPPORT_NOT_BOOTED` | 7908 | `9d5fb355cb155357…` | optional/full-host support |
| `modules/pubpartner_profiles.py` | `CANONICAL_ACTIVE` | 10489 | `7fa8aa537856a206…` | default runtime |
| `modules/pubpartner_provider.py` | `CANONICAL_ACTIVE` | 18780 | `cb83bc8db802e0e3…` | default runtime |
| `modules/pubpartner_rate_limit.py` | `CANONICAL_ACTIVE` | 1724 | `2efaf854a2180966…` | default runtime |
| `modules/pubpartner_receipts.py` | `CANONICAL_ACTIVE` | 3977 | `0547eeeeb1275beb…` | default runtime |
| `modules/pubpartner_relationship.py` | `CANONICAL_ACTIVE` | 21359 | `a0c51b9862dac811…` | default runtime |
| `modules/pubpartner_routes.py` | `CANONICAL_ACTIVE` | 28460 | `c1726e5b9b2d95c4…` | default runtime |
| `modules/pubpartner_tokens.py` | `CANONICAL_ACTIVE` | 2938 | `f04f804b3c6d3175…` | default runtime |
| `modules/pubpartner_voice.py` | `CANONICAL_ACTIVE` | 14750 | `cf3b4e8a20735342…` | default runtime |
| `modules/pubworld.py` | `CANONICAL_SUPPORT_NOT_BOOTED` | 2169 | `f05a134b9d143e57…` | optional/full-host support |
| `modules/pubworld_blocks.py` | `CANONICAL_SUPPORT_NOT_BOOTED` | 22452 | `bd059ef94ecf40d4…` | optional/full-host support |
| `modules/pubworld_hotspots.py` | `CANONICAL_SUPPORT_NOT_BOOTED` | 13459 | `846e25009ef15838…` | optional/full-host support |
| `modules/pubworld_router.py` | `CANONICAL_SUPPORT_NOT_BOOTED` | 4417 | `12afc9f5c22d862a…` | optional/full-host support |
| `modules/recording.py` | `CANONICAL_SUPPORT_NOT_BOOTED` | 25216 | `87702e0e0152fc0b…` | optional/full-host support |
| `modules/recording_pipeline.py` | `CANONICAL_SUPPORT_NOT_BOOTED` | 5990 | `ab82ab10d468747a…` | optional/full-host support |
| `modules/recording_pipeline_routes.py` | `CANONICAL_SUPPORT_NOT_BOOTED` | 4999 | `47d0622beb41fc3d…` | optional/full-host support |
| `modules/room_conductor.py` | `CANONICAL_SUPPORT_NOT_BOOTED` | 39254 | `0e94a923a48f88b0…` | optional/full-host support |
| `modules/rooms.py` | `CANONICAL_SUPPORT_NOT_BOOTED` | 9381 | `676f08cd712c7d68…` | optional/full-host support |
| `modules/route_security.py` | `CANONICAL_SUPPORT_NOT_BOOTED` | 4313 | `7ee0780de01fbe29…` | optional/full-host support |
| `modules/save_metadata.py` | `CANONICAL_SUPPORT_NOT_BOOTED` | 8116 | `0113fa434b817586…` | optional/full-host support |
| `modules/schemas.py` | `CANONICAL_ACTIVE` | 3363 | `a4848f84a5210509…` | default runtime |
| `modules/sculptor.py` | `CANONICAL_SUPPORT_NOT_BOOTED` | 7499 | `59e1e9beec38f9af…` | optional/full-host support |
| `modules/session_runtime.py` | `CANONICAL_SUPPORT_NOT_BOOTED` | 13286 | `ed5fc728fa1c32ec…` | optional/full-host support |
| `modules/sir_purfluous_character_profile.py` | `CANONICAL_SUPPORT_NOT_BOOTED` | 37892 | `6239ce1d89f0b173…` | optional/full-host support |
| `modules/skeleton_tracker.py` | `CANONICAL_SUPPORT_NOT_BOOTED` | 1790 | `8a150feaaf2a1fa7…` | optional/full-host support |
| `modules/split_llm.py` | `CANONICAL_SUPPORT_NOT_BOOTED` | 3528 | `a6600cb9f02ecd24…` | optional/full-host support |
| `modules/story_routes.py` | `CANONICAL_SUPPORT_NOT_BOOTED` | 1662 | `a8b5c5a424e61620…` | optional/full-host support |
| `modules/structured_log.py` | `CANONICAL_SUPPORT_NOT_BOOTED` | 2861 | `e91aa0e65c45e930…` | optional/full-host support |
| `modules/structured_log_routes.py` | `CANONICAL_SUPPORT_NOT_BOOTED` | 3378 | `cac8c21e2294c711…` | optional/full-host support |
| `modules/studio_control.py` | `CANONICAL_SUPPORT_NOT_BOOTED` | 22006 | `5a713e2145e83d94…` | optional/full-host support |
| `modules/studio_websocket.py` | `CANONICAL_SUPPORT_NOT_BOOTED` | 12286 | `64c66285c7311e85…` | optional/full-host support |
| `modules/surfaces.py` | `CANONICAL_SUPPORT_NOT_BOOTED` | 2494 | `de4903dca13efeac…` | optional/full-host support |
| `modules/system_memory.py` | `CANONICAL_SUPPORT_NOT_BOOTED` | 15990 | `28ed17802b880c25…` | optional/full-host support |
| `modules/timeline.py` | `CANONICAL_SUPPORT_NOT_BOOTED` | 13906 | `ea3663725c3120a0…` | optional/full-host support |
| `modules/timeline_routes.py` | `CANONICAL_SUPPORT_NOT_BOOTED` | 10007 | `b0b87aebdc11fc49…` | optional/full-host support |
| `modules/unity_bridge.py` | `CANONICAL_SUPPORT_NOT_BOOTED` | 16736 | `f98674b05be0745e…` | optional/full-host support |
| `modules/universal_memory_system.py` | `CANONICAL_SUPPORT_NOT_BOOTED` | 11365 | `567efb3b5b14fc10…` | optional/full-host support |
| `modules/userdb.py` | `CANONICAL_ACTIVE` | 10844 | `965b822d9f94c6dc…` | default runtime |
| `modules/vault_engine.py` | `CANONICAL_SUPPORT_NOT_BOOTED` | 24117 | `77283875dc0198b5…` | optional/full-host support |
| `modules/vault_engine_hardened.py` | `CANONICAL_SUPPORT_NOT_BOOTED` | 31548 | `049fa3df3004cc3e…` | optional/full-host support |
| `modules/voxel_asset_manager.py` | `CANONICAL_SUPPORT_NOT_BOOTED` | 25306 | `cff869274d0e4e6b…` | optional/full-host support |
| `modules/voxel_llm_adapter.py` | `CANONICAL_SUPPORT_NOT_BOOTED` | 12627 | `9c9aa3e8e2401fe5…` | optional/full-host support |
| `modules/voxel_studio_integration.py` | `CANONICAL_SUPPORT_NOT_BOOTED` | 10167 | `b0bd4a05915a9f7e…` | optional/full-host support |
| `modules/voxel_webrtc_bridge.py` | `CANONICAL_SUPPORT_NOT_BOOTED` | 11329 | `9ca6fcd8148cd713…` | optional/full-host support |
| `profiles/alex/README.md` | `CANONICAL_DOCUMENTATION` | 465 | `4a37fc57c45d8658…` |  |
| `profiles/alex/alex_candidate_extraction.jsonl` | `CANONICAL_SUPPORT` | 6813 | `2d09e175a30181ce…` |  |
| `profiles/alex/alex_source_manifest.json` | `CANONICAL_SUPPORT` | 4953 | `1919e025ac3390ae…` |  |
| `profiles/alex/boundaries.json` | `CANONICAL_SUPPORT` | 927 | `d2f2678c35840dd5…` |  |
| `profiles/alex/identity.json` | `CANONICAL_SUPPORT` | 863 | `935ffa9dfbec85db…` |  |
| `profiles/alex/modes.json` | `CANONICAL_SUPPORT` | 878 | `68c978ade778f2a3…` |  |
| `profiles/alex/negative_exemplars.jsonl` | `CANONICAL_SUPPORT` | 1111 | `1f0443632a575de3…` |  |
| `profiles/alex/positive_exemplars.jsonl` | `CANONICAL_SUPPORT` | 1897 | `0dcde178a917283d…` |  |
| `profiles/alex/voice.json` | `CANONICAL_SUPPORT` | 1008 | `f11fa522152fc819…` |  |
| `pubpartner_app.py` | `CANONICAL_ACTIVE` | 8665 | `129ee7bec367b59f…` | default runtime |
| `requirements-architect.txt` | `CANONICAL_SUPPORT` | 1612 | `a3419856bbc5351e…` |  |
| `requirements.txt` | `CANONICAL_SUPPORT` | 2121 | `fdeff8abd405c884…` |  |
| `run_pubpartner.py` | `CANONICAL_ACTIVE` | 4470 | `ab200d3d32e1e783…` | default runtime |
| `run_pubpartner_mac_linux.sh` | `CANONICAL_ACTIVE` | 326 | `379058a9043e6046…` | default runtime |
| `run_pubpartner_windows.ps1` | `CANONICAL_ACTIVE` | 1730 | `b378d60a57789b2c…` | default runtime |
| `rust_crate/Cargo.lock` | `CANONICAL_RUNTIME_BINARY` | 21983 | `1fe460912ec48c06…` |  |
| `rust_crate/Cargo.toml` | `CANONICAL_RUNTIME_BINARY` | 926 | `b4e490b9c367c328…` |  |
| `rust_crate/src/camera.rs` | `CANONICAL_RUNTIME_BINARY` | 4145 | `98606c12c5b23c07…` |  |
| `rust_crate/src/irm.rs` | `CANONICAL_RUNTIME_BINARY` | 256 | `9e4ba9d75f4d3a56…` |  |
| `rust_crate/src/lib.rs` | `CANONICAL_RUNTIME_BINARY` | 48 | `3f3783c0c1979a80…` |  |
| `rust_crate/src/renderer.rs` | `CANONICAL_RUNTIME_BINARY` | 206 | `88fbafe541a397e4…` |  |
| `scripts/bootstrap_dependencies.py` | `CANONICAL_SUPPORT` | 3614 | `edf9a36bc156d800…` |  |
| `scripts/build_release_manifest.py` | `CANONICAL_SUPPORT` | 2050 | `e021293e4f5f91ca…` |  |
| `scripts/pubpartner_control_plane_probe.py` | `CANONICAL_SUPPORT` | 7388 | `256e39740b4e7ad2…` |  |
| `scripts/pubpartner_restart_probe.py` | `CANONICAL_SUPPORT` | 7577 | `202b143dc853ec13…` |  |
| `scripts/pubpartner_smoke.py` | `CANONICAL_SUPPORT` | 2091 | `e15398b459a9bc3d…` |  |
| `scripts/sanitize_release.py` | `CANONICAL_SUPPORT` | 3173 | `03d3c978d2a8a1e9…` |  |
| `scripts/verify_release_manifest.py` | `CANONICAL_SUPPORT` | 1521 | `3e188bb4ca046532…` |  |
| `static/analytics.html` | `CANONICAL_UI_ASSET` | 3851 | `9c93b6a9905eb634…` |  |
| `static/app.js` | `CANONICAL_UI_ASSET` | 10725 | `c73b9e009f071bf7…` |  |
| `static/audio.js` | `CANONICAL_UI_ASSET` | 2655 | `f869cb9e8fe37dba…` |  |
| `static/avatar_glow.js` | `CANONICAL_UI_ASSET` | 12559 | `e368d7218e49817d…` |  |
| `static/avatar_studio_demo.html` | `CANONICAL_UI_ASSET` | 6622 | `183a5efac20bffde…` |  |
| `static/bar.html` | `CANONICAL_UI_ASSET` | 4852 | `1ce366e4c8bf98bc…` |  |
| `static/base.html` | `CANONICAL_UI_ASSET` | 1017 | `2393453fba15d338…` |  |
| `static/basebar.js` | `CANONICAL_UI_ASSET` | 5495 | `d696f81cac4d71a8…` |  |
| `static/pubpartner.css` | `CANONICAL_UI_ASSET` | 37514 | `4356aa837d6307f2…` |  |
| `static/pubpartner.html` | `CANONICAL_UI_ASSET` | 15825 | `f6300cc120db572e…` |  |
| `static/pubpartner.js` | `CANONICAL_UI_ASSET` | 42519 | `41fe8c6d61d348b8…` |  |
| `system_policy.json` | `CANONICAL_SUPPORT` | 1228 | `0cf0acf262b0cd04…` |  |
| `test_ai_characters.py` | `CANONICAL_TEST` | 6578 | `210b1ed7429f9030…` |  |
| `test_ollama_live.py` | `CANONICAL_TEST` | 4468 | `4fbc8048f616dd6d…` |  |
| `test_ollama_with_your_models.py` | `CANONICAL_TEST` | 6323 | `8c6e510286e68758…` |  |
| `test_v55_integration.py` | `CANONICAL_TEST` | 13407 | `4334673925b13bee…` |  |
| `tests/test_alex_foundation_pass.py` | `CANONICAL_TEST` | 5626 | `01a31c0294b57a83…` |  |
| `tests/test_alex_jeremy_bridge_contract.py` | `CANONICAL_TEST` | 11679 | `24746736597c5cf3…` |  |
| `tests/test_auth_productization.py` | `CANONICAL_TEST` | 5909 | `6e19d19d8a24b5d4…` |  |
| `tests/test_canonical_wiring_pass.py` | `CANONICAL_TEST` | 1616 | `2bc96e2d4ebd6937…` |  |
| `tests/test_epete_runtime_activation_pass_1.py` | `CANONICAL_TEST` | 3320 | `1c54d32fd1b5e69d…` |  |
| `tests/test_epete_voxel_bridge_pass_1.py` | `CANONICAL_TEST` | 3150 | `55f42a65372e38c1…` |  |
| `tests/test_opencode_zen_knowledge.py` | `CANONICAL_TEST` | 13040 | `e1705bb6077dba09…` |  |
| `tests/test_provider_neutralizer_rc6.py` | `CANONICAL_TEST` | 7533 | `b5a3efba8090a10e…` |  |
| `tests/test_pub_manager_authority.py` | `CANONICAL_TEST` | 907 | `6948df8dfe159599…` |  |
| `tests/test_pub_manager_decision_engine.py` | `CANONICAL_TEST` | 10217 | `6ce7cc545e990261…` |  |
| `tests/test_pub_manager_ui_wiring.py` | `CANONICAL_TEST` | 439 | `9be0ebc4ff1f904c…` |  |
| `tests/test_pubpartner_app_control_plane_wiring.py` | `CANONICAL_TEST` | 1650 | `0b9ca938a67b9036…` |  |
| `tests/test_pubpartner_backup.py` | `CANONICAL_TEST` | 1243 | `3e2038ba5dade749…` |  |
| `tests/test_pubpartner_live_loop.py` | `CANONICAL_TEST` | 5074 | `edc463a7c55c611e…` |  |
| `tests/test_pubpartner_relationship_engine.py` | `CANONICAL_TEST` | 2980 | `342358cfa2959205…` |  |
| `tests/test_pubpartner_relationship_review_ui.py` | `CANONICAL_TEST` | 384 | `7a2b49e9de22b6c8…` |  |
| `tests/test_pubpartner_repair10_cinematic_ui.py` | `CANONICAL_TEST` | 1440 | `14e73516a02a48dd…` |  |
| `tests/test_pubpartner_repair11_living_systems.py` | `CANONICAL_TEST` | 1755 | `24fbd1ba6deb0602…` |  |
| `tests/test_pubpartner_repair12_operable_living.py` | `CANONICAL_TEST` | 1691 | `f41576da247556f4…` |  |
| `tests/test_pubpartner_repair4_continuity.py` | `CANONICAL_TEST` | 4758 | `802db2d95c56a469…` |  |
| `tests/test_pubpartner_repair7_activation.py` | `CANONICAL_TEST` | 5143 | `b55564d103d53a5f…` |  |
| `tests/test_pubpartner_repair7_launch_check.py` | `CANONICAL_TEST` | 838 | `05604f96bcca2de1…` |  |
| `tests/test_pubpartner_repair8_lantern_ui.py` | `CANONICAL_TEST` | 2251 | `4bf0580e71a71ad5…` |  |
| `tests/test_pubpartner_repair9_hyperreal_ui.py` | `CANONICAL_TEST` | 919 | `9103d90dd0a739a8…` |  |
| `tests/test_pubpartner_routes.py` | `CANONICAL_TEST` | 1776 | `aaa8f3bf5dbc60e8…` |  |
| `tests/test_pubpartner_spine.py` | `CANONICAL_TEST` | 9159 | `bc3957bf7d4c7020…` |  |
| `tests/test_reconciliation_authority_adversarial.py` | `CANONICAL_TEST` | 3525 | `9f4a7a8a0ad9f15f…` |  |
| `tests/test_reconciliation_release_hygiene.py` | `CANONICAL_TEST` | 933 | `2376a6645e17cd18…` |  |
| `tests/test_storage_recovery.py` | `CANONICAL_TEST` | 1308 | `4f8fb038ee99f5c2…` |  |
| `tools/alex_restore.py` | `CANONICAL_SUPPORT` | 6631 | `8dbda0f13b772310…` |  |
| `tools/diagnostics/live_ollama_verification.py` | `CANONICAL_SUPPORT` | 12272 | `3733c5b24b74bfb2…` |  |
| `tools/diagnostics/run_ollama_verification.py` | `CANONICAL_SUPPORT` | 16398 | `f40fe5133c3fd7d8…` |  |

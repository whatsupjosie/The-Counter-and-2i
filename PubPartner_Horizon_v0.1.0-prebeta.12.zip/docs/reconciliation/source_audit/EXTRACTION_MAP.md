# Extraction Map

Archives were extracted into separate intake directories; duplicate byte-identical archives share one extraction.

| Archive | Status | Extracted directory | Alias of |
|---|---|---|---|
| `PubCast_v5_6_BubbleStack_WIRED_2026-07-06.zip` | EXTRACTED | `/mnt/data/PubPartner_Canonical_Reconciliation_20260712/intake/PubCast_v5_6_BubbleStack_WIRED_2026-07-06` | `` |
| `PubCast_v5_6_verified_and_fixed_2026-07-12.zip` | EXTRACTED | `/mnt/data/PubPartner_Canonical_Reconciliation_20260712/intake/PubCast_v5_6_verified_and_fixed_2026-07-12` | `` |
| `PubPartner_Handoff_2026-07-09.zip` | EXTRACTED | `/mnt/data/PubPartner_Canonical_Reconciliation_20260712/intake/PubPartner_Handoff_2026-07-09` | `` |
| `PubPartner_Handoff_2026-07-12 (1).zip` | EXTRACTED | `/mnt/data/PubPartner_Canonical_Reconciliation_20260712/intake/PubPartner_Handoff_2026-07-12_1` | `` |
| `PubPartner_Handoff_2026-07-12.zip` | DUPLICATE_ALIAS | `/mnt/data/PubPartner_Canonical_Reconciliation_20260712/intake/PubPartner_Handoff_2026-07-12_1` | `PubPartner_Handoff_2026-07-12_1` |
| `PubPartner_PRELAUNCH_RC2_PUB_MANAGER_20260711 (1).zip` | EXTRACTED | `/mnt/data/PubPartner_Canonical_Reconciliation_20260712/intake/PubPartner_PRELAUNCH_RC2_PUB_MANAGER_20260711_1` | `` |
| `PubPartner_PRELAUNCH_RC2_PUB_MANAGER_20260711.zip` | DUPLICATE_ALIAS | `/mnt/data/PubPartner_Canonical_Reconciliation_20260712/intake/PubPartner_PRELAUNCH_RC2_PUB_MANAGER_20260711_1` | `PubPartner_PRELAUNCH_RC2_PUB_MANAGER_20260711_1` |
| `PubPartner_PRELAUNCH_RC6_PROVIDER_NEUTRALIZER_20260712.zip` | EXTRACTED | `/mnt/data/PubPartner_Canonical_Reconciliation_20260712/intake/PubPartner_PRELAUNCH_RC6_PROVIDER_NEUTRALIZER_20260712` | `` |
| `PubPartner_RC2_HANDOFF_20260712.zip` | EXTRACTED | `/mnt/data/PubPartner_Canonical_Reconciliation_20260712/intake/PubPartner_RC2_HANDOFF_20260712` | `` |
| `alex_prime_core_handoff_package(4).zip` | EXTRACTED | `/mnt/data/PubPartner_Canonical_Reconciliation_20260712/intake/alex_prime_core_handoff_package_4` | `` |
| `alex_prime_core_v0_10(1).zip` | EXTRACTED | `/mnt/data/PubPartner_Canonical_Reconciliation_20260712/intake/alex_prime_core_v0_10_1` | `` |
| `alex_pub_partner_market_readiness_pass01_verified(1)(1).zip` | EXTRACTED | `/mnt/data/PubPartner_Canonical_Reconciliation_20260712/intake/alex_pub_partner_market_readiness_pass01_verified_1_1` | `` |
| `files (56).zip` | EXTRACTED | `/mnt/data/PubPartner_Canonical_Reconciliation_20260712/intake/files_56` | `` |

# Simple Windows Run Instructions

1. Extract the entire zip to a normal folder. Do not run it from inside the zip preview.
2. Double-click `RUN_PUBPARTNER_WINDOWS.bat`.
3. On the first run, allow it time to create `.venv` and install the required Python packages.
4. The browser should open after the local server is healthy.
5. Create the local owner account.
6. Alex is selected as the default friend.
7. To use Ollama, start Ollama, scan models in PubPartner, select a returned model, and run Provider Test.
8. To use Big Pickle, enter a valid OpenCode Zen BYOK key in the Online Reference Desk. Off is the default.
9. Stop PubPartner by returning to the launcher window and pressing `Ctrl+C`.

Requirements: Windows with Python 3.10 or newer available. A signed one-click installer is not included yet.

# Alex Restoration Foundation

This is a model-independent, layered starting profile. It is intentionally not a single giant persona prompt.

The active compact runtime profile lives in `data/pubpartner/profiles/friends/alex.json` and is seeded from code. These files preserve the fuller identity, voice, modes, boundaries, and evidence examples for later retrieval and comparative Alex builds.

Status: foundational candidate, not a claim of exact reconstruction.

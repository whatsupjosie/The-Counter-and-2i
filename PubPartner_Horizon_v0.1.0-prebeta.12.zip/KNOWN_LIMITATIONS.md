# Known Limitations

1. **Not publicly market-ready.** This is a verified private prelaunch candidate.
2. **Native Windows not directly executed.** Launchers were statically inspected and path-with-spaces preflight passed on Linux.
3. **Live Ollama unavailable.** Three live tests were skipped; local mock/offline flow passed.
4. **OpenAI-compatible live calls not exercised.** Optional library, endpoint and user key are required.
5. **Heavy studio hardware not exercised.** Camera, microphone, recording, renderer and WebRTC behavior remain environment-dependent.
6. **Full `main.py` is larger and riskier than the default app.** It remains for studio integration, not ordinary friend launch.
7. **Some studio modules contain explicit future-integration markers.** Compilation is not being misrepresented as complete product behavior.
8. **Alex Prime capabilities are not all merged.** The package was preserved as reference to avoid duplicate active identity/memory systems.
9. **Jeremy Hardened donor has one unresolved behavior failure.** It is not canonical.
10. **No installer, code signing, auto-update or public deployment hardening was completed in this pass.**

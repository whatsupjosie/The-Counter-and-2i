# Changed and Added Files

## Changed
- `RELEASE_MANIFEST.json`
- `VERSION`
- `static/pubpartner.js`
- `static/pubpartner.css`
- `static/pubpartner.html`

## Added
- `UI_TRANSPLANT_RELEASE_HANDOFF.md`
- `UI_ARCHITECTURE_STANDALONE_EMBEDDED.md`
- `UI_TRANSPLANT_CHANGELOG_20260728.md`
- `UI_TRANSPLANT_WEAKNESSES_REMAINING.md`
- `UI_TRANSPLANT_TEST_RESULTS.md`
- `tests/test_ui_workspace_transplant.py`

## Removed
- None

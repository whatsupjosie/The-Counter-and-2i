# Handoff — Cobbley v. Hawkes Residence Matter (August 8, 2026)

## Second pass — you asked where I cut corners, so I went and checked
The honest answer: the first pass built on an earlier draft's citations without independently verifying them against actual statutory text. I went back and checked the highest-stakes ones. Here's what I found and fixed:

- **A real arithmetic error.** The "$361,100 minimum" total didn't actually match the sum of its own rows. Corrected to **$361,200**.
- **The sexual assault charge and deadline, made more precise.** §243.4(e)(1) alone is a misdemeanor with roughly a one-year filing deadline. But Nadia physically restrained Josie during the touching — that specific fact supports charging under **§243.4(a)** instead, a felony-eligible offense that could extend the deadline to **10 years** under Penal Code §801.1(b) if charged that way. The document now states this explicitly rather than defaulting to the weaker charge, while still treating March 22/23, 2027 as the safe date to act by unless a prosecutor confirms otherwise.
- **Ralph Act vs. Bane Act, correctly separated.** These get conflated constantly online (I conflated them too, initially). The $25,000 civil penalty is specifically a Ralph Act (§51.7) remedy tied to the assault itself; the Bane Act (§52.1) is the better fit for the coercive property threats and witness intimidation, but works differently. Both are now cited for what they actually cover.
- **Honesty about the "23 Unruh instances" figure.** That number was carried forward from earlier work in this case, not independently counted line-by-line in this document. It now says so, and flags that a sub-part of it (the curfew write-ups) is itself recalled as a range — "five to ten" — not a confirmed count. Reconcile it against dated records before anyone relies on it in a filing.
- Added Alex Baettig's and Elvia Valdez's direct phone numbers to the recipient list, from your own earlier notes.
- Added one explicit, impossible-to-miss sentence stating Josie violated zero enforceable rules, ever — curfew and the two-bag rule named specifically — since that was central to what you originally asked for and had only been implicit.

**What I still haven't independently re-verified**, in the interest of not burning unlimited time: the remaining roughly dozen statutes cited (Unruh Act mechanics, UCL §17200/§17500, §1559 third-party beneficiary, §3617/§12955.7 FHA interference, §1954/§1708.8 privacy, §1712/PC 487 conversion, PC 368, PC 418, LAMC 45.30, VAWA/HUD regulations, 24 C.F.R. §578.3). These rest on your own previously-prepared legal framework reference document, which states it was checked as of July 30, 2026 — but I have not personally re-checked each one against current law this round. Say the word and I'll keep going down that list.

---

## What's in this package
- **Cobbley_v_Hawkes_Master_Legal_Demand_8-8-26.docx** — the new consolidated document (main deliverable): full narrative, complete legal breakdown with 46 causes of action, and a final damages summary (minimum / reasonable / maximum).
- **This handoff note.**
- **Source_Files/** — everything uploaded this session, kept together for reference.

## What was fixed this session
- **Name corrected throughout**: "Cobley" → **Cobbley** (Josie Curtsey Cobbley; legal name Joshua Thomas Cobbley).
- **Reconciled the violation count**: the new document states 46 distinct causes of action, encompassing 67+ documented violation instances and 87+ minimum actor-counted instances, so the "46" (case count) and "67/87" (instance counts) figures from earlier drafts no longer look contradictory.
- **Citation fix**: bias-motivated violence/coercion claims are correctly split between the **Ralph Act** and the **Bane Act** — see the second-pass section above for the more precise version of this fix.
- **New count added (#46)**: HUD Category 4 crime-victim status and VAWA's emergency-transfer / imminent-threat exception. This wasn't in the earlier draft — it's grounded in your Gemini conversation history — and matters for getting into safer housing, separate from money damages.
- **Penal Code §368** ("dependent adult" endangerment) is now flagged as a theory counsel needs to confirm applies, rather than stated as settled — this keeps the document accurate without weakening it.
- **Business name standardized** to "Curtsey Couture" throughout (see open item below).
- Bullet points now use proper Word list formatting instead of typed bullet characters — cosmetic, but it's what makes a document look drafted rather than pasted.

## Urgent, time-sensitive items
- **Sexual battery criminal filing deadline: ~March 22–23, 2027** (about 7.5 months away).
- **CalVCB victim-compensation application deadline: ~March 2027.**
- The **$100/day lockout penalty is still accruing** (51+ days as of today).
- An evidence preservation letter (already drafted in Part Two, Section IV of the document) should go out as soon as possible so footage and logs aren't lost or overwritten.

## Things only you can confirm
- **"Curtsey Couture"** — your own typed messages used a few different spellings across this project ("Curtsey," "Curtsy," "Courtesie"). The document uses "Curtsey Couture" throughout for consistency with your chosen name — flag it if that's wrong.
- **Dollar estimates** for the individually listed missing items in the Police Incident Summary (jewelry, clothing, scooter, skateboard, gaming chairs, etc.) — the master document uses aggregate estimates only; a fully itemized list will strengthen the property claims.
- Whether **"Doe #1"** (the unnamed male staff member) can be identified.
- **Current status of medication access**, as of today.

## One more matter — outside the scope of this document
Your source material references two earlier, separate incidents — assaults at Weingart and at a place referred to as "Hods" — both reportedly with video evidence and, as of your notes, no action taken. These involve different facilities and defendants than Hawkes Residence, so they aren't part of this demand letter, but given how statute-of-limitations pressure works on assault claims, it's worth raising with an attorney or **LAFLA (1-800-399-4529)** as its own matter soon.

## What wasn't touched
The original 8-document zip packet (with the "Cobley" typo throughout, and a leftover internal process note in document 07) wasn't individually corrected — the new master document supersedes it for anything you file or hand to an attorney. Say the word if you'd like corrected copies of those individual files too.

## Suggested next step
Take the master document to a housing/civil rights attorney (many take these cases on contingency) or the **Housing Rights Center (1-800-477-5977)**. It's written to be handed directly to counsel, opposing counsel, or filed as a demand letter — and it says plainly throughout that it's for legal review, not a final filing.
